Material Icon Usage =>
-------------------------------
<script src="https://use.fontawesome.com/5282b1c2d6.js"></script>
-------------------------------
App Download =>

-------
.exe
-------
-------------------------------
Github =>

url