function showElement() {
	document.getElementById('sub-header').style.display="block";
}